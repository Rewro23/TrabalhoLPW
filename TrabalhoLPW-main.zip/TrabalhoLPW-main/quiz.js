let botaoInicio = document.querySelector('#botao-iniciar');
let bodyEl = document.querySelector('body');

let vetorPerguntas = [];



botaoInicio.addEventListener('click', function() {
    botaoInicio.remove();

    for (let i = 0; i < 10; i++) {

    let quizPergunta = document.createElement('h1');
    let quizTextoPergunta = document.createElement('p');
    
    bodyEl.appendChild(quizPergunta);

    quizPergunta.innerHTML = (i + 1) + '°' + ' Pergunta:';

    bodyEl.appendChild(quizTextoPergunta);
    quizTextoPergunta.innerHTML = 'Texto pergunta ' + vetorPerguntas[i];

    let divRespostas = document.createElement('div');
    

    for (let j = 0; j < 4; j++) {
        let botaoResposta = document.createElement('button');
        botaoResposta.classList.add('botao-resposta');

        bodyEl.appendChild(divRespostas);
        divRespostas.appendChild(botaoResposta);

        botaoResposta.innerHTML = 'Resposta' + (j + 1);
        divRespostas.appendChild(botaoResposta);
        



    }

    }
    

});

